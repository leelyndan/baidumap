define(
		[ "text!app/main.html", "app/fnd/arch/page-loader",
				'app/fnd/arch/render', 'app/fnd/arch/wait',
				'app/fnd/arch/ajax-service' ], function(html, PageLoader,
				Render, Wait, AjaxService) {

			var main = null; 
 
			function Main() {

				this.enter = function(event) {

					$(window).bind("success", function() {

						alert('response successfully');
					});

					var $html = $(html);

					var $link = $html.find('#a_forward_main');

					$link.bind('click', function(e) {

						PageLoader.load('app/business/bus', {});

					});

					$html.find('#a_show_main').bind(
							'click',
							function(e) {

								var params = {
									userId : 'admin',
									password : 'admin'
								};
								var service = new AjaxService(
										'addressbook/login', 'login', params,
										onLoginSuccess);

								service.call();
							});

					$html.find('#a_hide_main').bind('click', function(e) {

						// Wait.hide();
						$(this).trigger("success", {});
					});

					return $html;

				};

				function onLoginSuccess(data) {

					alert(data);
				}

			}

			if (!main) {

				main = new Main();
				Render.render($('#div_content_index'), main.enter());
			}

			return main;

		});
