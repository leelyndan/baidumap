define([ 'text!app/business/bus.html', "app/fnd/arch/page-loader",
		'app/fnd/arch/render', 'handlebars' ], function(html, PageLoader,
		render, Handlebars) {

	var bus = null;

	function Bus() {

		this.enter = function(event) {

			// --------------
			var context = {
				name : "HAHA",
				content : "learn Handlebars"
			};
			var template = Handlebars.compile(html);
			var result = template(context);

			var $html = $(result);

			var $link = $html.find('#a_forward_bus');

			$link.bind('click', function(e) {

				PageLoader.load('app/main', {});

			});

			return $html;

		};

	}

	if (!bus) {

		bus = new Bus();
	}

	return bus;

});
