// Start loading the main app file. Put all of
// your application logic in there.
requirejs([ './common/config' ], function(common) {
	requirejs([ 'app/main' ]);
});
