define([ "lib", 'require', 'app/fnd/arch/render' ],
		function($, require, Render) {

			var pageLoader = null;

			function PageLoader() {
				var moduleCache = new Array();
				this.load = function(moduleName, event) {

					var loadedModule;

					if (moduleCache[moduleName]) {
						loadedModule = moduleCache[moduleName];
						renderProcess(loadedModule,event);
					} else {
						require([ moduleName ], function(module) {

							loadedModule = module;
							moduleCache[moduleName] = loadedModule;
							renderProcess(loadedModule,event);
						});
					}

				};

				function renderProcess(targetModule,event) {

					var $content = $('#div_content_index');
					if (targetModule && $.isFunction(targetModule.enter)) {
						Render.render($content, targetModule.enter(event));
					} else {
						console.log('load ' + moduleName + ' error.');
					}
				}
			}

			if (!pageLoader) {
				pageLoader = new PageLoader();
			}

			return pageLoader;
		});
