var dyn_modules = [];

define([ "lib", 'require' ], function($, require) {

	var render = null;

	function Render() {

		this.render = function(context, htmlContent) {

			var $content = $(context);

			$content.empty();

			var $htmlContent = $(htmlContent);

			var renderComponents = $htmlContent.find("[data-render]");

			$(renderComponents).each(function(item) {
				var that = this;
				var targetRenderName = $(this).data('render');
				var targetRenderPath = targetRenderName.replace(/\./g, '/');
				require([ targetRenderPath ], function(component) {

					var isRendered = $(component).attr("data-rendered");
					if (!isRendered) {
						component.render(that);
						$(component).attr("data-rendered", true);
					}
				});

			});

			$content.prepend($htmlContent);
		};
	}

	if (!render) {
		render = new Render();
	}

	return render;
});
