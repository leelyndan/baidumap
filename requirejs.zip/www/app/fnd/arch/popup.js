define([ "lib" ], function($) {

	var popup = null;

	function Popup() {
		var $htmlContent = $("<div id='div_popup_arch'></div>");
		this.init = function(html) {
			var $html = !!html ? $(html) : null;
			$htmlContent.css('background', 'rgb(202, 199, 199)').css('position', 'absolute')
					.css('top', '0').css('left', '0').css('display', 'block')
					.css('opacity', '0.8');
			if ($html) {
				$htmlContent.width($html.width());
				$htmlContent.height($html.height());
				$htmlContent.css('top', $html.offset().top).css('left',
						$html.offset().left);
			}else{
				$htmlContent.height($(window).height());
				$htmlContent.width($(window).width());
			}
			return $htmlContent;

		};

	}
	if (!popup) {

		popup = new Popup();
	}
	return popup;
});
