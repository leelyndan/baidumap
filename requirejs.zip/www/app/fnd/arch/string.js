/*
 * from: http://code.google.com/p/closure-library/source/browse/trunk/closure/goog/string/string.js
 */
define([ "lib" ],

function($) {

	String = new function() {

		var that = this;

		var unsafeHtml = new RegExp(
				'<script|</script>|<link|</link>|<%|%>|on[a-zA-Z]*="');

		this.containsUnsafeHtml = function(html) {
			if (html != null && !that.isEmpty(html)) {
				if (html.toLowerCase().match(unsafeHtml)) {
					return true;
				}
			}
			return false;
		};

		this.isEmpty = function(str) {
			// testing length == 0 first is actually slower in all browsers
			// (about the
			// same in Opera).
			// Since IE doesn't include non-breaking-space (0xa0) in their \s
			// character
			// class (as required by section 7.2 of the ECMAScript spec), we
			// explicitly
			// include it in the regexp to enforce consistent cross-browser
			// behavior.
			return /^[\s\xa0]*$/.test(str);
		};
		/**
		 * Checks if a string is null, empty or contains only whitespaces.
		 * 
		 * @param {*}
		 *            str The string to check.
		 * @return {boolean} True if{@code str} is null, empty, or whitespace
		 *         only.
		 */
		this.isEmptySafe = function(str) {
			str = str == null ? '' : String(str);
			return that.isEmpty(str);
		};

		/**
		 * Converts the supplied string to a number, which may be Ininity or
		 * NaN. This function strips whitespace: (toNumber(' 123') === 123) This
		 * function accepts scientific notation: (toNumber('1e1') === 10)
		 * 
		 * This is better than Javascript's built-in conversions because, sadly:
		 * (Number(' ') === 0) and (parseFloat('123a') === 123)
		 * 
		 * @param {string}
		 *            str The string to convert.
		 * @return {number} The number the supplied string represents, or NaN.
		 */
		this.toNumber = function(str) {
			var num = Number(str);
			if (num == 0 && that.isEmpty(str)) {
				return NaN;
			}
			return num;
		};

		/**
		 * Checks if a string contains only numbers.
		 * 
		 * @param {*}
		 *            str string to check. If not a string, it will be casted to
		 *            one.
		 * @return {boolean} True if {@code str} is numeric.
		 */
		this.isNumeric = function(str) {
			return !/[^0-9]/.test(str);
		};

		/**
		 * Fast prefix-checker.
		 * 
		 * @param {string}
		 *            str The string to check.
		 * @param {string}
		 *            prefix A string to look for at the start of {@code str}.
		 * @return {boolean} True if {@code str} begins with {@code prefix}.
		 */
		this.startsWith = function(str, prefix) {
			return str.lastIndexOf(prefix, 0) == 0;
		};
		this.endsWith = function(str, suffix) {
			var l = str.length - suffix.length;
			return l >= 0 && str.indexOf(suffix, l) == l;
		};
		this.caseInsensitiveStartsWith = function(str, prefix) {
			return that.caseInsensitiveCompare(prefix, str.substr(0,
					prefix.length)) == 0;
		};

		this.caseInsensitiveEndsWith = function(str, suffix) {
			return that.caseInsensitiveCompare(suffix, str.substr(str.length
					- suffix.length, suffix.length)) == 0;
		};

		this.caseInsensitiveCompare = function(str1, str2) {
			var test1 = String(str1).toLowerCase();
			var test2 = String(str2).toLowerCase();
			if (test1 < test2) {
				return -1;
			} else if (test1 == test2) {
				return 0;
			} else {
				return 1;
			}
		};

		this.htmlEscape = function(str, opt_isLikelyToContainHtmlChars) {
			if (opt_isLikelyToContainHtmlChars) {
				return str.replace(string.amperRe_, '&amp;').replace(
						string.ltRe_, '&lt;').replace(string.gtRe_, '&gt;')
						.replace(string.quotRe_, '&quot;');
			} else {
				if (str.indexOf('&') != -1) {
					str = str.replace(string.amperRe_, '&amp;');
				}
				if (str.indexOf('<') != -1) {
					str = str.replace(string.ltRe_, '&lt;');
				}
				if (str.indexOf('>') != -1) {
					str = str.replace(string.gtRe_, '&gt;');
				}
				if (str.indexOf('"') != -1) {
					str = str.replace(string.quotRe_, '&quot;');
				}
				return str;
			}
		};
	};
	return String;
}

);