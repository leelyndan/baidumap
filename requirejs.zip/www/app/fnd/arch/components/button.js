define([], function() {

	var button = null;

	function Button() {

		this.render = function(html) {

			var $html = $(html);
			renderStyle($html);
			bindClick($html);
		};

		function bindClick($html) {

			$html.bind('click', function() {
				$(this).trigger("success", {});
				// alert('the button was clicked');
			});

		}

		function renderStyle($html) {

			$html.css('background', 'red');

		}

	}

	if (!button) {

		button = new Button();
	}

	return button;
});