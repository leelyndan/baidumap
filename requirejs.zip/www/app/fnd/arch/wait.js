define(
    ["lib", 'app/fnd/arch/popup'],
    function($, Popup) {

        var wait = null;

        function Wait() {
            var $popup = null;
            var $loadingImage = $("<img src='www/imgs/loading.gif'></img>");
            this.show = function(html) {
                var $html = !!html ? $(html) : null;
                if ($html) {
                    $popup = Popup.init($html);
                } else {
                    $popup = Popup.init();
                }
                $loadingImage.width('60px');
                $loadingImage.height('60px');
                var marginLeft = ($popup.width() / 2) - ($loadingImage.width() / 2);
                var marginTop = ($popup.height() / 2) - ($loadingImage.height() / 2);
                $loadingImage.css('margin-left', marginLeft);
                $loadingImage.css('margin-top', marginTop);

                $popup.append($loadingImage);
                $('body').append($popup);

            };

            this.hide = function($html) {

                // var $waiting = $('#div_waiting_common');

                if (!$popup) {
                    return;
                }

                $popup.remove();

            };

        }

        if (!wait) {

            wait = new Wait();
        }
        return wait;
    });
