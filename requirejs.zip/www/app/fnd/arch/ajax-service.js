define(
    [
        "lib",
        "app/fnd/arch/wait"
    ],
    function($, Wait) {

        var UID = 1;
        var ajaxService = null;

        var SuccessEvent = function(data, textStatus, jqXHR) {
            this.data = data;
            this.textStatus = textStatus;
            this.jqXHR = jqXHR;
        };
        var ExceptionEvent = function(data, textStatus, jqXHR) {
            this.data = data;
            this.textStatus = textStatus;
            this.jqXHR = jqXHR;
        };
        var ErrorEvent = function(jqXHR, textStatus, errorThrown) {
            this.jqXHR = jqXHR;
            this.textStatus = textStatus;
            this.errorThrown = errorThrown;
        };
        var ResultEvent = function(isError, result, textStatus, jqXHR) {
            this.isError = isError;
            this.result = result;
            this.textStatus = textStatus;
            this.jqXHR = jqXHR;
        };


        function AjaxService(clazz, method, params, successCallback, exceptionCallback, errorCallback) {
            var that = $(this);
            var id = UID++;
            console.time("Service call (" + id + ")");
            var serviceUrl = "" + clazz + "/" + method + '.do';
            var paramsJson;
            if (params === null) {
                paramsJson = null;
            } else {
                var clientOs = "Unknown";
                if (navigator.platform.indexOf("Win") >= 0) {
                    clientOs = "Win";
                } else if (navigator.platform.indexOf("Mac") >= 0) {
                    clientOs = "Mac"
                }
                params.clientOs = clientOs;

                paramsJson = JSON.stringify(params);
            }
            console.log(serviceUrl);
            console.log("Params: ", params);


            this.call = function(wait) {
                var token;
                if (wait) {
                    token = wait;
                }
                var properties = {};

                properties.url = serviceUrl;
                properties.type = "post";
                properties.data = JSON.parse(paramsJson);
                //  properties.contentType = "application/json";
                properties.success = onSuccess;
                properties.error = onError;
                $.ajax(properties);
                /**
                 * @private
                 */
                function onSuccess(data, textStatus, jqXHR) {
                    if (data && data.isError) {
                        console.log('Exception');
                    } else {
                        console.log('Success');
                    }
                    console.log("Data: ", data);
                    console.timeEnd("Service call (" + id + ")");
                    if (data && data.isError) {
                        if (data.type == "AuthenticationException") {
                            console.error("User not authenticated, redirecting to logout");
                            window.location.assign("/logout");
                        } else if (exceptionCallback) {
                            exceptionCallback(data, textStatus, jqXHR);
                        } else {
                            console.error("Uncaught service exception");
                            var message = "";
                            if (data.message) {
                                message = data.message.substr(0, 300);
                            }
                            popup.error("Exception: check console log for details\n\n" + message);
                        }
                        that.trigger("exception", new ExceptionEvent(data, textStatus, jqXHR));
                    } else {
                        if (successCallback) {
                            successCallback(data, textStatus, jqXHR);
                        }
                        that.trigger("success", new SuccessEvent(data, textStatus, jqXHR));
                    }
                    that.trigger("result", new ResultEvent(false, data, textStatus, jqXHR));
                    if (token) {
                        token.hide();
                    }
                }
                /**
                 * @private
                 */
                function onError(jqXHR, textStatus, errorThrown) {
                    if (token) {
                        token.hide();
                    }
                    console.log('Fail');
                    console.log("Status: ", textStatus);
                    console.log("Error: ", errorThrown);
                    console.timeEnd("Service call (" + id + ")");
                    if (errorCallback) {
                        errorCallback(jqXHR, textStatus, errorThrown);
                    } else {
                        popup.error("An error occurred trying to connect to a service. You may no longer be connected to the " +
                            "internet or another network error occurred.\n\n" + errorThrown);
                    }
                    that.trigger("error", new ErrorEvent(jqXHR, textStatus, errorThrown));
                    that.trigger("result", new ResultEvent(true, errorThrown, textStatus, jqXHR));
                }
            };
        };

        return AjaxService;
    });
